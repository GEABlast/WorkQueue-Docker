/*
Copyright (C) 2013- The University of Notre Dame
This software is distributed under the GNU General Public License.
See the file COPYING for details.
*/

#ifndef UPTIME_H
#define UPTIME_H

int uptime_get();

#endif
