/*
Copyright (C) 2017- The University of Notre Dame
This software is distributed under the GNU General Public License.
See the file COPYING for details.
*/

#ifndef INTERFACES_ADDRESS_H
#define INTERFACES_ADDRESS_H

#include  "jx.h"

struct jx *interfaces_of_host();

#endif
