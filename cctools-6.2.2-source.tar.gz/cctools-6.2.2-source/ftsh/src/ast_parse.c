/*
Copyright (C) 2003-2004 Douglas Thain and the University of Wisconsin
Copyright (C) 2005- The University of Notre Dame
This software is distributed under the GNU General Public License.
See the file COPYING for details.
*/
/*
The Fault-Tolerant Shell is Copyright (C) 2002 by Douglas Thain
This file is released under the GNU General Public License.
See the file COPYING for details.
*/

#

/* vim: set noexpandtab tabstop=4: */
